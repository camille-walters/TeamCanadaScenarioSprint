Hi! We're MindFluX, and we make art happen!

> This is a texture mapped, game-ready model which can be used in any of your games
> Texture files are included, but the model employs mainly materials (for increased quality)
> You can use this in any of your games or apps (commercial or free) but do include us in the credits (as "MindFluX Studios" without the quotes)
> You may not edit this model but you can re-distribute it (but include this README file)

Thanks, 
The MindFluX Team